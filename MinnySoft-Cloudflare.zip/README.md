# MinnySoft website

Cloudflare Pages-ready React/Vite single-page website.

## Run locally

```bash
npm install
npm run dev
```

## Cloudflare Pages settings

- Framework preset: **Vite**
- Build command: `npm run build`
- Build output directory: `dist`
- Production branch: `main`

## Connect minnysoft.com

After the first successful deployment, open the Pages project in Cloudflare, select **Custom domains**, then add `minnysoft.com`. Add `www.minnysoft.com` too if required. Cloudflare will show the DNS records that must be created or updated.
