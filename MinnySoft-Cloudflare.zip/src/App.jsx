const services = [
  { number: "01", title: "Microsoft AI", text: "Build governed enterprise AI with Azure AI Foundry, Azure OpenAI, Microsoft Copilot Studio, Microsoft 365 Copilot, and intelligent Power Platform workflows.", tags: ["Azure AI", "Copilot", "Power Platform"] },
  { number: "02", title: "AWS AI", text: "Design secure generative AI and machine-learning solutions using Amazon Bedrock, SageMaker, Lambda, and cloud-native data services.", tags: ["Bedrock", "SageMaker", "AWS Cloud"] },
  { number: "03", title: "Google Cloud AI", text: "Create data-grounded AI experiences with Vertex AI, Gemini, BigQuery, and Google Cloud’s scalable analytics and integration services.", tags: ["Vertex AI", "Gemini", "BigQuery"] },
  { number: "04", title: "SaaS AI solutions", text: "Connect AI capabilities across ServiceNow, Salesforce, Workday, Dynamics 365, and other enterprise SaaS platforms—without creating new data silos.", tags: ["ServiceNow", "Salesforce", "Workday"] },
  { number: "05", title: "Enterprise architecture", text: "Define target architectures, capability roadmaps, platform standards, AI guardrails, integration patterns, and investments aligned to business outcomes.", tags: ["Strategy", "Governance", "Roadmaps"] },
  { number: "06", title: "Legacy modernization", text: "Move from tightly coupled legacy estates to modular cloud platforms through portfolio assessment, API enablement, data modernization, and phased migration.", tags: ["Cloud migration", "APIs", "Data platforms"] },
];

const principles = [
  ["Clarity first", "One accountable team, plain-language decisions, and progress you can see."],
  ["Built for change", "Modular foundations that adapt as your customers and business evolve."],
  ["Secure by design", "Security, privacy, and operational readiness considered from the first sketch."],
];

function Arrow({ diagonal = false }) { return <span aria-hidden="true" className="arrow">{diagonal ? "↗" : "→"}</span>; }

export default function App() {
  return <main>
    <header className="site-header">
      <a className="brand" href="#top" aria-label="MinnySoft home"><span className="brand-mark" aria-hidden="true"><i/><i/><i/></span><span>minny<span>soft</span></span></a>
      <nav aria-label="Main navigation"><a href="#services">Services</a><a href="#approach">Approach</a><a href="#about">About</a></nav>
      <a className="header-cta" href="mailto:hello@minnysoft.com">Let’s talk <Arrow diagonal/></a>
    </header>
    <section className="hero" id="top">
      <div className="hero-copy"><p className="eyebrow"><span/> Enterprise AI, cloud & architecture</p><h1>Enterprise AI.<br/><em>Architected</em> for impact.</h1><p className="hero-intro">MinnySoft helps enterprises adopt AI across Microsoft, AWS, Google Cloud, and SaaS platforms—supported by strong architecture, governance, and modernization.</p><div className="hero-actions"><a className="button primary" href="mailto:hello@minnysoft.com">Discuss your initiative <Arrow/></a><a className="text-link" href="#services">Explore our services <Arrow diagonal/></a></div></div>
      <div className="hero-visual" aria-label="Connected digital products"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="signal-card card-one"><span className="status-dot"/> live systems</div><div className="signal-card card-two"><b>99.9%</b><span>built for reliability</span></div><div className="signal-card card-three"><span>idea</span><Arrow/><strong>impact</strong></div><div className="core"><span>M</span></div></div>
      <div className="hero-footnote"><span>AI Strategy</span><span>Architecture</span><span>Cloud Platforms</span><span>Modernization</span></div>
    </section>
    <section className="proof-strip" aria-label="MinnySoft expertise"><p>From AI strategy to secure enterprise delivery.</p><div><span>Cloud</span><i/><span>AI</span><i/><span>Architecture</span><i/><span>Modernization</span></div></section>
    <section className="section services" id="services"><div className="section-heading"><p className="eyebrow">Our expertise</p><h2>AI across every<br/>enterprise platform.</h2><p>We connect cloud AI, enterprise SaaS, data, security, and architecture into one practical transformation roadmap.</p></div><div className="platform-line"><span>Microsoft</span><span>AWS</span><span>Google Cloud</span><span>Enterprise SaaS</span><span>Architecture</span></div><div className="service-grid">{services.map(s=><article className="service-card" key={s.number}><div className="service-top"><span>{s.number}</span><Arrow diagonal/></div><h3>{s.title}</h3><p>{s.text}</p><div className="tags">{s.tags.map(tag=><span key={tag}>{tag}</span>)}</div></article>)}</div></section>
    <section className="section approach" id="approach"><div className="approach-panel"><p className="eyebrow light">Transformation approach</p><h2>Modernize with<br/><em>control</em> and momentum.</h2><p>We assess the current estate, define a secure target architecture, prove value through focused use cases, and migrate in phases while keeping business operations stable.</p><a className="button light-button" href="mailto:hello@minnysoft.com">Discuss your roadmap <Arrow/></a></div><ol className="steps"><li><span>01</span><div><h3>Assess</h3><p>Map business capabilities, applications, data, integrations, risk, and technical debt.</p></div></li><li><span>02</span><div><h3>Architect</h3><p>Define target platforms, AI guardrails, integration patterns, and transition states.</p></div></li><li><span>03</span><div><h3>Prove</h3><p>Validate priority AI and modernization use cases with measurable outcomes.</p></div></li><li><span>04</span><div><h3>Scale</h3><p>Industrialize delivery, migration, security, observability, and governance.</p></div></li></ol></section>
    <section className="section principles" id="about"><div className="section-heading compact"><p className="eyebrow">Why MinnySoft</p><h2>Strategy that reaches<br/>production.</h2></div><div className="principle-list">{principles.map(([title,text],i)=><article key={title}><span>0{i+1}</span><h3>{title}</h3><p>{text}</p></article>)}</div></section>
    <section className="contact-section"><p className="eyebrow light">Planning an AI or modernization initiative?</p><h2>Build the roadmap.<br/><em>Deliver the outcome.</em></h2><a href="mailto:hello@minnysoft.com">hello@minnysoft.com <Arrow diagonal/></a></section>
    <footer><a className="brand footer-brand" href="#top"><span className="brand-mark" aria-hidden="true"><i/><i/><i/></span><span>minny<span>soft</span></span></a><p>Enterprise AI, cloud, and modernization.</p><p>© 2026 MinnySoft</p></footer>
  </main>;
}
